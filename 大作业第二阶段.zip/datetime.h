#include <string>
using namespace std;

string Current_TimeStamp();
string CurDate();
string CurTime();
string addtime(string& op);
string adddate(string& op);