程序运行环境（除远程访问之外的功能）
- macOS Mojave10.14.3  
Apple LLVM version 10.0.0 (clang-1000.10.44.4)  
Target: x86_64-apple-darwin18.2.0
- win10 gcc verson 4.9.2
远程访问只能在MacOS运行